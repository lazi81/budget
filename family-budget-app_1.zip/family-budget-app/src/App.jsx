import { useState, useEffect, useCallback } from "react";
import { db } from "./firebase";
import {
  collection, addDoc, deleteDoc, doc, onSnapshot,
  query, orderBy, setDoc, getDoc
} from "firebase/firestore";

const CATEGORIES = [
  { id: "groceries", label: "Groceries", icon: "🛒", color: "#4CAF50" },
  { id: "dining", label: "Dining", icon: "🍽️", color: "#FF9800" },
  { id: "transport", label: "Transport", icon: "🚗", color: "#2196F3" },
  { id: "bills", label: "Bills", icon: "📄", color: "#9C27B0" },
  { id: "health", label: "Health", icon: "💊", color: "#E91E63" },
  { id: "shopping", label: "Shopping", icon: "🛍️", color: "#00BCD4" },
  { id: "entertainment", label: "Fun", icon: "🎬", color: "#FF5722" },
  { id: "other", label: "Other", icon: "📌", color: "#607D8B" },
];

const MEMBERS = [
  { id: "member1", name: "Member 1", color: "#6C63FF" },
  { id: "member2", name: "Member 2", color: "#FF6584" },
  { id: "member3", name: "Member 3", color: "#43B988" },
];

const CURRENCY = "₪";

function formatDate(ts) {
  const d = new Date(ts);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

function getCurrentMonth() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export default function App() {
  const [expenses, setExpenses] = useState([]);
  const [memberNames, setMemberNames] = useState({
    member1: "Member 1", member2: "Member 2", member3: "Member 3",
  });
  const [view, setView] = useState("home");
  const [showAdd, setShowAdd] = useState(false);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [selectedCat, setSelectedCat] = useState("groceries");
  const [selectedMember, setSelectedMember] = useState("member1");
  const [loading, setLoading] = useState(true);
  const [editingName, setEditingName] = useState(null);
  const [tempName, setTempName] = useState("");

  // Real-time listener for expenses
  useEffect(() => {
    const q = query(collection(db, "expenses"), orderBy("timestamp", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setExpenses(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Real-time listener for member names
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, "settings", "memberNames"), (snap) => {
      if (snap.exists()) setMemberNames(snap.data());
    });
    return () => unsubscribe();
  }, []);

  const currentMonth = getCurrentMonth();
  const monthExpenses = expenses.filter((e) => {
    const d = new Date(e.timestamp);
    const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    return m === currentMonth;
  });

  const totalMonth = monthExpenses.reduce((s, e) => s + e.amount, 0);
  const byCategory = CATEGORIES.map((cat) => ({
    ...cat,
    total: monthExpenses.filter((e) => e.category === cat.id).reduce((s, e) => s + e.amount, 0),
  })).filter((c) => c.total > 0).sort((a, b) => b.total - a.total);

  const byMember = MEMBERS.map((m) => ({
    ...m,
    name: memberNames[m.id] || m.name,
    total: monthExpenses.filter((e) => e.member === m.id).reduce((s, e) => s + e.amount, 0),
  }));

  const recentExpenses = expenses.slice(0, 30);
  const maxCat = byCategory.length > 0 ? byCategory[0].total : 1;

  const handleAdd = async () => {
    if (!amount || isNaN(parseFloat(amount))) return;
    try {
      await addDoc(collection(db, "expenses"), {
        amount: parseFloat(amount),
        category: selectedCat,
        member: selectedMember,
        note: note.trim(),
        timestamp: Date.now(),
      });
      setAmount("");
      setNote("");
      setShowAdd(false);
    } catch (e) {
      alert("Error adding expense. Check your internet connection.");
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteDoc(doc(db, "expenses", id));
    } catch (e) {
      alert("Error deleting expense.");
    }
  };

  const handleNameEdit = (memberId) => {
    setEditingName(memberId);
    setTempName(memberNames[memberId] || "");
  };

  const handleNameSave = async () => {
    if (tempName.trim()) {
      const newNames = { ...memberNames, [editingName]: tempName.trim() };
      setMemberNames(newNames);
      try {
        await setDoc(doc(db, "settings", "memberNames"), newNames);
      } catch (e) {
        alert("Error saving name.");
      }
    }
    setEditingName(null);
  };

  if (loading) {
    return (
      <div style={s.loadingWrap}>
        <div style={{ fontSize: 48 }}>💰</div>
        <p style={{ marginTop: 16, fontSize: 14, opacity: 0.6 }}>Loading family budget...</p>
      </div>
    );
  }

  return (
    <div style={s.app}>
      {/* Header */}
      <div style={s.header}>
        <div style={s.headerTop}>
          <span style={s.logo}>💰 Family Budget</span>
          <span style={s.syncBadge}>● Live</span>
        </div>
        <div style={s.monthLabel}>
          {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
        </div>
        <div style={s.totalAmount}>
          {CURRENCY}{totalMonth.toLocaleString("en-US", { minimumFractionDigits: 0 })}
        </div>
        <div style={s.totalSub}>total spent this month</div>
      </div>

      {/* Member Chips */}
      <div style={s.membersRow}>
        {byMember.map((m) => (
          <div key={m.id} style={{ ...s.memberChip, borderColor: m.color }} onClick={() => handleNameEdit(m.id)}>
            <div style={{ ...s.memberDot, background: m.color }}>{m.name[0]}</div>
            <div>
              <div style={s.memberName}>{m.name}</div>
              <div style={s.memberTotal}>{CURRENCY}{m.total.toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Name Edit Modal */}
      {editingName && (
        <div style={s.overlay} onClick={() => setEditingName(null)}>
          <div style={s.nameModal} onClick={(e) => e.stopPropagation()}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Edit Name</div>
            <input
              style={s.noteInput}
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              placeholder="Enter name"
              maxLength={15}
              autoFocus
              onKeyDown={(e) => e.key === "Enter" && handleNameSave()}
            />
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button style={s.cancelBtn} onClick={() => setEditingName(null)}>Cancel</button>
              <button style={s.saveBtn} onClick={handleNameSave}>Save</button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div style={s.tabs}>
        {["home", "history", "breakdown"].map((t) => (
          <button
            key={t}
            style={view === t ? { ...s.tab, ...s.tabActive } : s.tab}
            onClick={() => setView(t)}
          >
            {t === "home" ? "📊 Overview" : t === "history" ? "📋 History" : "📂 Categories"}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={s.content}>
        {view === "home" && (
          <>
            <div style={s.section}>
              <div style={s.sectionTitle}>Spending by Category</div>
              {byCategory.length === 0 && (
                <div style={s.emptyState}>No expenses yet this month. Tap + to add one!</div>
              )}
              {byCategory.map((cat) => (
                <div key={cat.id} style={s.barRow}>
                  <span style={{ fontSize: 20, width: 28, textAlign: "center" }}>{cat.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={s.barLabel}>
                      <span>{cat.label}</span>
                      <span style={{ color: "#8B8FA3", fontWeight: 500, fontSize: 12 }}>{CURRENCY}{cat.total.toLocaleString()}</span>
                    </div>
                    <div style={s.barTrack}>
                      <div style={{ height: "100%", borderRadius: 3, width: `${(cat.total / maxCat) * 100}%`, background: cat.color, transition: "width 0.5s ease" }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div style={s.section}>
              <div style={s.sectionTitle}>Recent Expenses</div>
              {recentExpenses.slice(0, 5).map((exp) => (
                <ExpenseRow key={exp.id} exp={exp} memberNames={memberNames} />
              ))}
            </div>
          </>
        )}

        {view === "history" && (
          <div style={s.section}>
            <div style={s.sectionTitle}>All Expenses</div>
            {recentExpenses.length === 0 && <div style={s.emptyState}>No expenses recorded yet.</div>}
            {recentExpenses.map((exp) => (
              <ExpenseRow key={exp.id} exp={exp} memberNames={memberNames} onDelete={handleDelete} />
            ))}
          </div>
        )}

        {view === "breakdown" && (
          <div style={s.section}>
            <div style={s.sectionTitle}>Category Breakdown</div>
            {CATEGORIES.map((cat) => {
              const catTotal = monthExpenses.filter((e) => e.category === cat.id).reduce((sum, e) => sum + e.amount, 0);
              const pct = totalMonth > 0 ? ((catTotal / totalMonth) * 100).toFixed(1) : 0;
              return (
                <div key={cat.id} style={s.catCard}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <span style={{ ...s.catIcon, background: cat.color + "22", color: cat.color }}>{cat.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 700 }}>{cat.label}</div>
                      <div style={{ fontSize: 11, color: "#5A5E72", marginTop: 1 }}>{pct}% of total</div>
                    </div>
                    <div style={{ fontSize: 16, fontWeight: 800, color: cat.color }}>{CURRENCY}{catTotal.toLocaleString()}</div>
                  </div>
                  {catTotal > 0 && (
                    <div style={{ height: 4, borderRadius: 2, background: "#1A1D27", marginTop: 12 }}>
                      <div style={{ height: "100%", borderRadius: 2, width: `${pct}%`, background: cat.color, transition: "width 0.5s ease" }} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FAB */}
      <button style={s.fab} onClick={() => setShowAdd(true)}>+</button>

      {/* Add Modal */}
      {showAdd && (
        <div style={s.overlay} onClick={() => setShowAdd(false)}>
          <div style={s.modal} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <span style={{ fontSize: 18, fontWeight: 700 }}>Add Expense</span>
              <button style={{ background: "none", border: "none", color: "#5A5E72", fontSize: 18, cursor: "pointer" }} onClick={() => setShowAdd(false)}>✕</button>
            </div>
            <div style={s.amountWrap}>
              <span style={{ fontSize: 28, fontWeight: 700, color: "#5A5E72" }}>{CURRENCY}</span>
              <input style={s.amountInput} type="number" inputMode="decimal" placeholder="0" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus />
            </div>
            <input style={s.noteInput} placeholder="Add a note (optional)" value={note} onChange={(e) => setNote(e.target.value)} />

            <div style={s.fieldLabel}>Who spent?</div>
            <div style={s.memberPicker}>
              {MEMBERS.map((m) => (
                <button key={m.id}
                  style={selectedMember === m.id
                    ? { ...s.memberBtn, borderColor: m.color, background: m.color + "15", color: "#E8E8ED" }
                    : s.memberBtn}
                  onClick={() => setSelectedMember(m.id)}
                >
                  <span style={{ ...s.memberBtnDot, background: m.color }}>{(memberNames[m.id] || m.name)[0]}</span>
                  <span>{memberNames[m.id] || m.name}</span>
                </button>
              ))}
            </div>

            <div style={s.fieldLabel}>Category</div>
            <div style={s.catPicker}>
              {CATEGORIES.map((cat) => (
                <button key={cat.id}
                  style={selectedCat === cat.id
                    ? { ...s.catBtn, borderColor: cat.color, background: cat.color + "15", color: "#E8E8ED" }
                    : s.catBtn}
                  onClick={() => setSelectedCat(cat.id)}
                >
                  <span>{cat.icon}</span>
                  <span style={{ fontSize: 10, fontWeight: 600 }}>{cat.label}</span>
                </button>
              ))}
            </div>

            <button style={amount ? s.submitBtn : { ...s.submitBtn, opacity: 0.4 }} onClick={handleAdd}>
              Add Expense
            </button>
          </div>
        </div>
      )}

      <div style={{ textAlign: "center", padding: "16px 0 32px" }}>
        <button style={s.resetBtn} onClick={async () => {
          if (confirm("Clear ALL expenses? This cannot be undone.")) {
            for (const exp of expenses) {
              await deleteDoc(doc(db, "expenses", exp.id));
            }
          }
        }}>Reset All Data</button>
      </div>
    </div>
  );
}

function ExpenseRow({ exp, memberNames, onDelete }) {
  const cat = CATEGORIES.find((c) => c.id === exp.category);
  const mem = MEMBERS.find((m) => m.id === exp.member);
  return (
    <div style={s.expenseRow}>
      <span style={{ ...s.expIcon, background: cat?.color + "22", color: cat?.color }}>{cat?.icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 14, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{exp.note || cat?.label}</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#FF6584", flexShrink: 0, marginLeft: 8 }}>-{CURRENCY}{exp.amount.toLocaleString()}</span>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 3 }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: mem?.color }}>{memberNames[exp.member] || mem?.name}</span>
          <span style={{ fontSize: 11, color: "#5A5E72" }}>{formatDate(exp.timestamp)}</span>
        </div>
      </div>
      {onDelete && (
        <button style={{ background: "none", border: "none", color: "#3A3E52", fontSize: 14, cursor: "pointer", padding: "4px 8px" }} onClick={() => onDelete(exp.id)}>✕</button>
      )}
    </div>
  );
}

const s = {
  app: { fontFamily: "'DM Sans', sans-serif", maxWidth: 480, margin: "0 auto", minHeight: "100vh", background: "#0D0F14", color: "#E8E8ED", position: "relative", paddingBottom: 100 },
  loadingWrap: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", background: "#0D0F14", color: "#E8E8ED", fontFamily: "'DM Sans', sans-serif" },
  header: { background: "linear-gradient(145deg, #1A1D27 0%, #12141B 100%)", padding: "28px 24px 24px", borderBottom: "1px solid #1E2130" },
  headerTop: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  logo: { fontSize: 18, fontWeight: 700, letterSpacing: "-0.02em" },
  syncBadge: { fontSize: 11, color: "#43B988", background: "#43B98815", padding: "4px 10px", borderRadius: 20, fontWeight: 600 },
  monthLabel: { fontSize: 13, color: "#8B8FA3", marginBottom: 4, fontWeight: 500 },
  totalAmount: { fontSize: 42, fontWeight: 800, letterSpacing: "-0.03em", color: "#FFFFFF" },
  totalSub: { fontSize: 12, color: "#5A5E72", marginTop: 2 },
  membersRow: { display: "flex", gap: 8, padding: "16px 16px 8px", overflowX: "auto" },
  memberChip: { display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: "#151720", borderRadius: 14, border: "1px solid #1E2130", cursor: "pointer", flexShrink: 0, minWidth: 120, borderLeftWidth: 3, borderLeftStyle: "solid" },
  memberDot: { width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#fff", flexShrink: 0 },
  memberName: { fontSize: 12, fontWeight: 600, color: "#C0C3D1" },
  memberTotal: { fontSize: 14, fontWeight: 700 },
  tabs: { display: "flex", padding: "8px 16px", gap: 6, borderBottom: "1px solid #1A1D27" },
  tab: { flex: 1, padding: "10px 0", fontSize: 12, fontWeight: 600, background: "transparent", border: "none", color: "#5A5E72", cursor: "pointer", borderRadius: 10, transition: "all 0.2s" },
  tabActive: { background: "#1A1D27", color: "#E8E8ED" },
  content: { padding: "8px 16px" },
  section: { marginBottom: 24 },
  sectionTitle: { fontSize: 13, fontWeight: 700, color: "#5A5E72", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 12, marginTop: 8 },
  emptyState: { textAlign: "center", padding: 32, color: "#3A3E52", fontSize: 14 },
  barRow: { display: "flex", gap: 12, alignItems: "center", marginBottom: 14 },
  barLabel: { display: "flex", justifyContent: "space-between", marginBottom: 5, fontSize: 13, fontWeight: 600 },
  barTrack: { height: 6, borderRadius: 3, background: "#1A1D27" },
  expenseRow: { display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid #151720" },
  expIcon: { width: 40, height: 40, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 },
  catCard: { background: "#151720", borderRadius: 14, padding: "14px 16px", marginBottom: 8, border: "1px solid #1E2130" },
  catIcon: { width: 38, height: 38, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 },
  fab: { position: "fixed", bottom: 28, right: "calc(50% - 220px)", width: 56, height: 56, borderRadius: "50%", border: "none", background: "linear-gradient(135deg, #6C63FF 0%, #897CFF 100%)", color: "#fff", fontSize: 28, fontWeight: 300, cursor: "pointer", boxShadow: "0 4px 24px #6C63FF44", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100 },
  overlay: { position: "fixed", inset: 0, background: "#000000AA", zIndex: 200, display: "flex", alignItems: "flex-end", justifyContent: "center" },
  modal: { background: "#151720", borderRadius: "24px 24px 0 0", padding: "24px 20px 32px", width: "100%", maxWidth: 480, maxHeight: "90vh", overflowY: "auto", border: "1px solid #1E2130", borderBottom: "none" },
  amountWrap: { display: "flex", alignItems: "center", gap: 8, background: "#0D0F14", borderRadius: 16, padding: "16px 20px", marginBottom: 12 },
  amountInput: { flex: 1, background: "transparent", border: "none", color: "#FFFFFF", fontSize: 32, fontWeight: 800, outline: "none", fontFamily: "inherit", width: "100%" },
  noteInput: { width: "100%", background: "#0D0F14", border: "1px solid #1E2130", borderRadius: 12, padding: "12px 16px", color: "#E8E8ED", fontSize: 14, outline: "none", fontFamily: "inherit", marginBottom: 16, boxSizing: "border-box" },
  fieldLabel: { fontSize: 12, fontWeight: 700, color: "#5A5E72", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" },
  memberPicker: { display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" },
  memberBtn: { display: "flex", alignItems: "center", gap: 8, padding: "8px 14px", background: "#0D0F14", border: "1.5px solid #1E2130", borderRadius: 12, color: "#8B8FA3", cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "inherit" },
  memberBtnDot: { width: 24, height: 24, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff" },
  catPicker: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 8, marginBottom: 20 },
  catBtn: { display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "10px 4px", background: "#0D0F14", border: "1.5px solid #1E2130", borderRadius: 12, cursor: "pointer", fontSize: 20, fontFamily: "inherit", color: "#8B8FA3" },
  submitBtn: { width: "100%", padding: "14px 0", border: "none", borderRadius: 14, background: "linear-gradient(135deg, #6C63FF 0%, #897CFF 100%)", color: "#fff", fontSize: 16, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  nameModal: { background: "#151720", borderRadius: 20, padding: 24, width: 300, border: "1px solid #1E2130", position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)" },
  cancelBtn: { padding: "8px 18px", background: "#0D0F14", border: "1px solid #1E2130", borderRadius: 10, color: "#8B8FA3", cursor: "pointer", fontFamily: "inherit", fontWeight: 600, fontSize: 13 },
  saveBtn: { padding: "8px 18px", background: "#6C63FF", border: "none", borderRadius: 10, color: "#fff", cursor: "pointer", fontFamily: "inherit", fontWeight: 600, fontSize: 13 },
  resetBtn: { background: "none", border: "none", color: "#3A3E52", fontSize: 12, cursor: "pointer", fontFamily: "inherit", textDecoration: "underline" },
};
