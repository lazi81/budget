import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBAYC-IQ6iyRLKRsnEMx1o6VSMs0iZRW9A",
  authDomain: "family-budget-99cc4.firebaseapp.com",
  projectId: "family-budget-99cc4",
  storageBucket: "family-budget-99cc4.firebasestorage.app",
  messagingSenderId: "290515357330",
  appId: "1:290515357330:web:2567c2112cfe15d7dba04b",
  measurementId: "G-7ZWG4547FE",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
